package org.simpleframework.transport.trace;

public class MockTrace implements Trace{
   public void trace(Object event) {}
   public void trace(Object event, Object value) {}
}
